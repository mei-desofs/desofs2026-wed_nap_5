package com.grupo.learningmore.api;

import com.grupo.learningmore.domain.course.Course;
import com.grupo.learningmore.dto.Request.CreateCourseRequest;
import com.grupo.learningmore.dto.Response.CourseResponse;
import com.grupo.learningmore.services.CourseService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @PreAuthorize("hasRole('PROFESSOR') or hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<CourseResponse> createCourse(
            Authentication authentication,
            @Valid @RequestBody CreateCourseRequest request
    ) {
        UUID userId = UUID.fromString(authentication.getName());

        Course course = courseService.createCourse(
                request.code(),
                request.name(),
                request.description(),
                userId
        );

        CourseResponse response = mapToCourseResponse(course);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('PROFESSOR') or hasRole('ADMIN')")
    public ResponseEntity<CourseResponse> getCourseById(@PathVariable UUID id) {
        Course course = courseService.findById(id);
        return ResponseEntity.ok(mapToCourseResponse(course));
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<CourseResponse> getCourseByCode(@PathVariable String code) {
        Course course = courseService.findByCode(code);
        return ResponseEntity.ok(mapToCourseResponse(course));
    }

    @GetMapping
    public ResponseEntity<List<CourseResponse>> getAllCourses() {
        List<Course> courses = courseService.findAll();
        List<CourseResponse> responses = courses.stream()
                .map(this::mapToCourseResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @PreAuthorize("hasRole('PROFESSOR') or hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<CourseResponse> updateCourse(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateCourseRequest request
    ) {
        Course course = courseService.updateCourse(
                id,
                request.name(),
                request.description()
        );

        return ResponseEntity.ok(mapToCourseResponse(course));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCourse(@PathVariable UUID id) {
        courseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }

    private CourseResponse mapToCourseResponse(Course course) {
        return new CourseResponse(
                course.getId(),
                course.getCode(),
                course.getName(),
                course.getDescription(),
                course.getCreatedAt(),
                course.getUpdatedAt(),
                course.getCreatedBy()
        );
    }

    public record UpdateCourseRequest(
            String name,
            String description
    ) {
    }
}
